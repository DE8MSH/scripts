#ifndef MAHJONG_LOGIC_H
#define MAHJONG_LOGIC_H
#ifdef SGDK_GCC
#include <genesis.h>
#else
#include <stdint.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#endif

enum { MAJ_TITLE=0, MAJ_PLAY=1, MAJ_RON=2, MAJ_PLAYER_WINS=3, MAJ_CPU_WINS=4, MAJ_DRAW=5 };
enum { MAJ_TSUMO=1, MAJ_RON_WIN=2 };

typedef struct {
    u8 bag[136], human[14], cpu[14];
    u8 humanDiscard[136], cpuDiscard[136];
    u8 hLen, cLen, hDiscardLen, cDiscardLen;
    u8 pos, phase, cursor, hRiichi, cRiichi, riichiRequest;
    u8 hRiichiPaid, cRiichiPaid, lastCpuTile, winMode;
    u16 hands, humanPoints, cpuPoints;
    u32 rng;
} Mahjong;

void MAJ_seed(Mahjong *m, u32 seed);
void MAJ_newRound(Mahjong *m);
void MAJ_start(Mahjong *m, u32 seed);
void MAJ_sort(u8 *hand, u8 n);
int MAJ_isWin(const u8 *hand, u8 n);
int MAJ_tenpai(const u8 *hand, u8 n);
int MAJ_humanTsumo(Mahjong *m);
int MAJ_humanDiscard(Mahjong *m, u8 handIndex);
int MAJ_humanRon(Mahjong *m);
void MAJ_passRon(Mahjong *m);
int MAJ_humanCanRiichiAfterDiscard(const Mahjong *m, u8 i);
int MAJ_humanCanTsumo(const Mahjong *m);
int MAJ_isFuriten(const u8 *hand, u8 handLen, const u8 *discards, u8 discardsLen);
#endif
