#include "mahjong.h"

static u32 nextRand(Mahjong *m) {
    u32 x=m->rng;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    m->rng = x ? x : 0x1337ABCDUL;
    return m->rng;
}
void MAJ_seed(Mahjong *m, u32 seed) { m->rng = seed ? seed : 0xC0FFEE12UL; }
void MAJ_sort(u8 *h, u8 n) {
    u8 i,j,v;
    for (i=1;i<n;i++) { v=h[i]; j=i; while(j && h[j-1]>v){h[j]=h[j-1];j--;}h[j]=v; }
}
static int melds(u8 *c) {
    int i;
    for (i=0;i<34;i++) if (c[i]) break;
    if (i==34) return 1;
    if (c[i]>=3) { c[i]-=3; if (melds(c)) { c[i]+=3;return 1; } c[i]+=3; }
    if (i<27 && (i%9)<7 && c[i+1] && c[i+2]) {
        c[i]--; c[i+1]--; c[i+2]--;
        if (melds(c)) { c[i]++;c[i+1]++;c[i+2]++;return 1; }
        c[i]++;c[i+1]++;c[i+2]++;
    }
    return 0;
}
int MAJ_isWin(const u8 *hand, u8 n) {
    u8 c[34]={0};
    int i, pairs=0, extras=0;
    static const u8 orphan[13]={0,8,9,17,18,26,27,28,29,30,31,32,33};
    if (n!=14) return 0;
    for (i=0;i<14;i++) { if (hand[i]>33 || ++c[hand[i]]>4) return 0; }
    for(i=0;i<34;i++) if(c[i]==2) pairs++;
    if (pairs==7) return 1;
    for(i=0;i<13;i++) {
        if (!c[orphan[i]]) break;
        if (c[orphan[i]]>=2) extras++;
    }
    if(i==13 && extras==1) return 1;
    for(i=0;i<34;i++) if(c[i]>=2) {
        c[i]-=2;
        if (melds(c)) return 1;
        c[i]+=2;
    }
    return 0;
}
int MAJ_tenpai(const u8 *hand, u8 n) {
    u8 h[14],counts[34]={0};int i,t;
    if (n!=13) return 0;
    for (i=0;i<13;i++) { if(hand[i]>33)return 0;h[i]=hand[i];counts[hand[i]]++; }
    for(t=0;t<34;t++) if(counts[t]<4){ h[13]=(u8)t; if(MAJ_isWin(h,14))return 1; }
    return 0;
}
int MAJ_isFuriten(const u8 *hand,u8 n,const u8 *disc,u8 dlen) {
    u8 tmp[14],counts[34]={0}; int i,t,j;
    if(n!=13)return 0;
    for(i=0;i<13;i++){tmp[i]=hand[i];if(hand[i]>33)return 0;counts[hand[i]]++;}
    for(t=0;t<34;t++) if(counts[t]<4){
        tmp[13]=(u8)t;
        if(MAJ_isWin(tmp,14)) for(j=0;j<dlen;j++) if(disc[j]==t)return 1;
    }
    return 0;
}
static int tanyao(const u8 *hand,u8 n) {
    int i;for(i=0;i<n;i++) if(hand[i]>=27 || hand[i]%9==0 || hand[i]%9==8)return 0;
    return 1;
}
static int valueTriplet(const u8 *hand,u8 n,int isEast) {
    int c[34]={0},i; for(i=0;i<n;i++)c[hand[i]]++;
    for(i=31;i<34;i++) if(c[i]>=3)return 1;
    if(c[isEast?27:28]>=3)return 1;
    return 0;
}
static int naturalYaku(const u8 *hand,u8 n,int isEast) {
    int i,suit=-1,flush=1;
    int counts[34]={0},seven=0,allMeldsTrip=0;
    if(tanyao(hand,n)||valueTriplet(hand,n,isEast))return 1;
    for(i=0;i<n;i++) {
        int v=hand[i]; counts[v]++;
        if(v>=27)continue;
        else if(suit<0)suit=v/9;
        else if(suit!=v/9)flush=0;
    }
    if(flush)return 1; /* Honitsu / Chinitsu / Tsuuiisou */
    for(i=0;i<34;i++) {if(counts[i]==2)seven++;if(counts[i]==3)allMeldsTrip++;}
    if(seven==7 || allMeldsTrip==4)return 1;
    return 0;
}
static u8 pull(Mahjong *m) { return (m->pos<136) ? m->bag[m->pos++] : 255; }
static void score(Mahjong *m,int player,int mode) {
    u16 pts=(mode==MAJ_TSUMO?1600:1200);
    if(player){ if(m->hRiichi)pts+=1000; m->humanPoints+=pts;m->phase=MAJ_PLAYER_WINS; }
    else { if(m->cRiichi)pts+=1000; m->cpuPoints+=pts;m->phase=MAJ_CPU_WINS; }
    m->winMode=(u8)mode;
}
static int canWinRon(const u8 *hand,u8 n,int riichi,int isEast,const u8 *disc,u8 dlen,u8 tile) {
    u8 h[14];int i;
    if(n!=13 || MAJ_isFuriten(hand,13,disc,dlen))return 0;
    for(i=0;i<13;i++) h[i]=hand[i];
    h[13]=tile;
    return MAJ_isWin(h,14) && (riichi || naturalYaku(h,14,isEast));
}
static int eval13(const u8 *h) {
    int c[34]={0},t,score=0;
    for(t=0;t<13;t++)c[h[t]]++;
    for(t=0;t<34;t++) {
        if(c[t]>=3)score+=18;
        else if(c[t]==2)score+=10;
        else if(c[t]==1)score+=(t>=27?-2:1);
        if(t<27){
            if(t%9<8){score+=c[t]*c[t+1]*5;}
            if(t%9<7){score+=c[t]*c[t+2]*2;}
        }
    }
    return score;
}
static u8 cpuPick(Mahjong *m) {
    int i,j,s,best=-100000;u8 idx=0,h[13];
    if((nextRand(m)%7)==0)return (u8)(nextRand(m)%14); /* forgiving CPU */
    for(i=0;i<14;i++) {
        for(j=0,s=0;j<14;j++)if(j!=i)h[s++]=m->cpu[j];
        s=eval13(h);
        if(s>best){best=s;idx=(u8)i;}
    }
    return idx;
}
static void cpuTurn(Mahjong *m) {
    u8 t,idx;int i;
    if(m->phase!=MAJ_PLAY)return;
    if(m->pos>=136){m->phase=MAJ_DRAW;return;}
    t=pull(m);
    if(t==255){m->phase=MAJ_DRAW;return;}
    m->cpu[13]=t;m->cLen=14;
    if(MAJ_isWin(m->cpu,14)){score(m,0,MAJ_TSUMO);return;}
    idx=m->cRiichi?13:cpuPick(m);
    t=m->cpu[idx];
    for(i=idx;i<13;i++)m->cpu[i]=m->cpu[i+1];
    m->cLen=13; MAJ_sort(m->cpu,13);
    m->cpuDiscard[m->cDiscardLen++]=t;
    m->lastCpuTile=t;
    if(!m->cRiichi && m->cpuPoints>=1000 && MAJ_tenpai(m->cpu,13)){
        if((nextRand(m)%3)!=0) {m->cRiichi=1;m->cpuPoints-=1000;m->cRiichiPaid=1;}
    }
    if(canWinRon(m->human,13,m->hRiichi,1,m->humanDiscard,m->hDiscardLen,t)) {
        m->phase=MAJ_RON; return;
    }
    if(m->pos>=136){m->phase=MAJ_DRAW;return;}
    t=pull(m);
    if(t==255){m->phase=MAJ_DRAW;return;}
    m->human[13]=t;m->hLen=14;
    if(!m->hRiichi)MAJ_sort(m->human,14);
    m->cursor=m->hRiichi?13:0;
}
void MAJ_newRound(Mahjong *m) {
    int i,j;u8 t;
    m->hLen=13;m->cLen=13;m->hDiscardLen=0;m->cDiscardLen=0;
    m->hRiichi=0;m->cRiichi=0;m->hRiichiPaid=0;m->cRiichiPaid=0;
    m->riichiRequest=0;m->cursor=0;m->lastCpuTile=255;m->winMode=0;
    for(i=0;i<136;i++)m->bag[i]=(u8)(i/4);
    for(i=135;i>0;i--) {j=(int)(nextRand(m)%(u32)(i+1));t=m->bag[i];m->bag[i]=m->bag[j];m->bag[j]=t;}
    m->pos=0;
    for(i=0;i<13;i++){m->human[i]=pull(m);m->cpu[i]=pull(m);}
    MAJ_sort(m->human,13);MAJ_sort(m->cpu,13);
    m->human[13]=pull(m);m->hLen=14;MAJ_sort(m->human,14);
    m->phase=MAJ_PLAY;m->hands++;
}
void MAJ_start(Mahjong *m,u32 seed) {
    MAJ_seed(m,seed);m->humanPoints=10000;m->cpuPoints=10000;m->hands=0;MAJ_newRound(m);
}
int MAJ_humanCanTsumo(const Mahjong *m) {
    return m->phase==MAJ_PLAY && m->hLen==14 && MAJ_isWin(m->human,14);
}
int MAJ_humanTsumo(Mahjong *m){if(!MAJ_humanCanTsumo(m))return 0;score(m,1,MAJ_TSUMO);return 1;}
int MAJ_humanCanRiichiAfterDiscard(const Mahjong *m,u8 i){
    u8 h[13];int j,k=0;
    if(m->hRiichi || m->humanPoints<1000 || m->phase!=MAJ_PLAY || m->hLen!=14 || i>=14)return 0;
    for(j=0;j<14;j++)if(j!=i)h[k++]=m->human[j];
    return MAJ_tenpai(h,13);
}
int MAJ_humanDiscard(Mahjong *m,u8 i) {
    u8 t;int j;
    if(m->phase!=MAJ_PLAY || m->hLen!=14 || i>=14)return 0;
    if(m->hRiichi && i!=13)return 0;
    if(m->riichiRequest && !MAJ_humanCanRiichiAfterDiscard(m,i))return 0;
    if(m->riichiRequest){m->humanPoints-=1000;m->hRiichi=1;m->hRiichiPaid=1;}
    m->riichiRequest=0;
    t=m->human[i];
    for(j=i;j<13;j++)m->human[j]=m->human[j+1];
    m->hLen=13;MAJ_sort(m->human,13);
    m->humanDiscard[m->hDiscardLen++]=t;
    if(canWinRon(m->cpu,13,m->cRiichi,0,m->cpuDiscard,m->cDiscardLen,t)){
        score(m,0,MAJ_RON_WIN);return 1;
    }
    cpuTurn(m);
    return 1;
}
int MAJ_humanRon(Mahjong *m) {
    if(m->phase!=MAJ_RON)return 0;
    if(!canWinRon(m->human,13,m->hRiichi,1,m->humanDiscard,m->hDiscardLen,m->lastCpuTile))return 0;
    score(m,1,MAJ_RON_WIN);return 1;
}
void MAJ_passRon(Mahjong *m) {
    u8 t;
    if(m->phase!=MAJ_RON)return;
    /* Passing RON produces temporary Furiten in standard Riichi. This compact
       variant does not expose that state; never automatically win after pass. */
    m->phase=MAJ_PLAY;
    if(m->pos>=136){m->phase=MAJ_DRAW;return;}
    t=pull(m);m->human[13]=t;m->hLen=14;
    if(!m->hRiichi)MAJ_sort(m->human,14);
    m->cursor=m->hRiichi?13:0;
}
