/* Mahjong Duel v0.6 - genuine SGDK entrypoint; no custom vectors, no naked VDP writes. */
#include <genesis.h>
#include "mahjong.h"
#include "tile_art.h"

static Mahjong g;
static u16 screenRows;
static char note[40];
static u16 lastPad=0;
static u32 frameCounter=0;

#define ART(i) (TILE_USER_INDEX + ((i) * 8))
#define PATTERN (TILE_USER_INDEX + 288)
#define GOLDLINE (TILE_USER_INDEX + 289)

static const u16 uiPal[16]={
    RGB24_TO_VDPCOLOR(0x08181D),RGB24_TO_VDPCOLOR(0x143940),
    RGB24_TO_VDPCOLOR(0x205258),RGB24_TO_VDPCOLOR(0xE3B255),
    RGB24_TO_VDPCOLOR(0xFFE0A0),RGB24_TO_VDPCOLOR(0xF7F2D9),
    RGB24_TO_VDPCOLOR(0xF8F6E9),RGB24_TO_VDPCOLOR(0xFFFFFF),
    RGB24_TO_VDPCOLOR(0xFFFFFF),RGB24_TO_VDPCOLOR(0xFFFFFF),
    RGB24_TO_VDPCOLOR(0xFFFFFF),RGB24_TO_VDPCOLOR(0xFFFFFF),
    RGB24_TO_VDPCOLOR(0xFFFFFF),RGB24_TO_VDPCOLOR(0xFFFFFF),
    RGB24_TO_VDPCOLOR(0xFFFFFF),RGB24_TO_VDPCOLOR(0xFFFFFF)
};
static const u16 stonePal[16]={
    RGB24_TO_VDPCOLOR(0x08181D),RGB24_TO_VDPCOLOR(0x143940),
    RGB24_TO_VDPCOLOR(0xE2DABB),RGB24_TO_VDPCOLOR(0xFFF9E1),
    RGB24_TO_VDPCOLOR(0x94A8A5),RGB24_TO_VDPCOLOR(0xE7B352),
    RGB24_TO_VDPCOLOR(0xBF3C41),RGB24_TO_VDPCOLOR(0x2C9267),
    RGB24_TO_VDPCOLOR(0x3471A9),RGB24_TO_VDPCOLOR(0x0D3E5B),
    RGB24_TO_VDPCOLOR(0xD8CB9E),RGB24_TO_VDPCOLOR(0xFFD263),
    RGB24_TO_VDPCOLOR(0x845340),RGB24_TO_VDPCOLOR(0x698D8F),
    RGB24_TO_VDPCOLOR(0xE9EEDA),RGB24_TO_VDPCOLOR(0x081215)
};

static void drawDigits(u16 val,char *dst) {
    dst[0]='0'+((val/10000)%10);
    dst[1]='0'+((val/1000)%10);
    dst[2]='0'+((val/100)%10);
    dst[3]='0'+((val/10)%10);
    dst[4]='0'+(val%10);
    dst[5]=0;
}
static void stone(u8 id,u16 x,u16 y) {
    u16 sx,sy,first=ART(id);
    for(sy=0;sy<4;sy++)for(sx=0;sx<2;sx++)
        VDP_setTileMapXY(BG_A,TILE_ATTR_FULL(PAL1,0,0,0,first+(sy*2)+sx),x+sx,y+sy);
}
static void clearScene(void) {
    VDP_clearPlane(BG_A,TRUE);
    VDP_fillTileMapRect(BG_B,TILE_ATTR_FULL(PAL1,0,0,0,PATTERN),0,0,40,screenRows);
}
static void bar(u16 y) {
    if(y>=screenRows)return;
    VDP_fillTileMapRect(BG_B,TILE_ATTR_FULL(PAL1,0,0,0,GOLDLINE),0,y,40,1);
}
static void centered(const char *str,u16 y){
    u16 n=0;while(str[n])n++;
    if(n<=40)VDP_drawText(str,(40-n)/2,y);
}
static void titleScreen(void) {
    int i;
    clearScene(); bar(1); bar(7); bar(22);bar(screenRows-2);
    centered("M A H J O N G    D U E L",3);
    centered("- SEGA MEGA DRIVE EDITION -",5);
    centered("SHOGUN TABLE",9);
    for(i=0;i<7;i++)stone((u8)((i*5+2)%34),(u16)(7+i*4),12);
    centered("CHALLENGE THE CPU",18);
    centered("PRESS START",20);
    centered("CLOSED-HAND RIICHI MAHJONG",24);
    centered("SGDK ENGINE  /  DO7OO  /  v0.6",26);
}
static void printScore(void){
    char b[6];
    VDP_drawText("YOU",2,2);drawDigits(g.humanPoints,b);VDP_drawText(b,6,2);
    VDP_drawText("CPU",27,2);drawDigits(g.cpuPoints,b);VDP_drawText(b,31,2);
    VDP_drawText(g.hRiichi?"RIICHI":"      ",13,2);
}
static void sceneGame(void) {
    u8 i,start;
    clearScene();bar(0);bar(18);bar(screenRows-2);
    centered("MAHJONG  DUEL  -  CPU MATCH",0);
    printScore();
    VDP_drawText("OPPONENT",2,3);
    if(g.cRiichi)VDP_drawText("REACH!",30,3);
    for(i=0;i<13;i++)stone(34,(u16)(7+i*2),4);
    VDP_drawText("CPU DISCARDS",2,9);
    start=g.cDiscardLen>10?(g.cDiscardLen-10):0;
    for(i=start;i<g.cDiscardLen;i++)stone(g.cpuDiscard[i],(u16)(10+(i-start)*2),10);
    VDP_drawText("YOUR DISCARDS",2,14);
    start=g.hDiscardLen>10?(g.hDiscardLen-10):0;
    for(i=start;i<g.hDiscardLen;i++)stone(g.humanDiscard[i],(u16)(10+(i-start)*2),14);
    VDP_drawText("YOUR HAND",2,19);
    for(i=0;i<g.hLen;i++)stone(g.human[i],(u16)(6+i*2),20);
    if(g.phase==MAJ_PLAY && g.cursor<14){
        VDP_drawText("^",(u16)(6+g.cursor*2),24);
    }
    if(g.phase==MAJ_RON){
        VDP_drawText("RON POSSIBLE!  A:WIN  B:PASS",1,25);
    } else if(g.phase==MAJ_PLAYER_WINS){
        VDP_drawText(g.winMode==MAJ_TSUMO?"YOU WIN!   TSUMO":"YOU WIN!   RON",10,25);
    } else if(g.phase==MAJ_CPU_WINS){
        VDP_drawText("CPU WINS THIS ROUND",10,25);
    } else if(g.phase==MAJ_DRAW){
        VDP_drawText("DRAW - NO TILES LEFT",10,25);
    } else if(g.riichiRequest){
        VDP_drawText("REACH? CHOOSE TILE THEN C",4,25);
    } else if(g.hRiichi){
        VDP_drawText("REACH! A:TSUMO  C:DISCARD",4,25);
    } else {
        VDP_drawText("A:TSUMO  B:REACH  C:DISCARD",3,25);
    }
    if(g.phase==MAJ_PLAYER_WINS || g.phase==MAJ_CPU_WINS || g.phase==MAJ_DRAW)
        centered("START: NEXT HAND",27);
    else
        centered("LEFT/RIGHT: SELECT   START: HELP",27);
    if(note[0])VDP_drawText(note,1,26);
}
static void showHelp(void) {
    clearScene();bar(1);bar(screenRows-2);
    centered("MAHJONG DUEL - HOW TO PLAY",3);
    centered("LEFT/RIGHT : SELECT TILE",6);
    centered("C : DISCARD SELECTED TILE",8);
    centered("A : TSUMO / RON IF AVAILABLE",10);
    centered("B : REACH BEFORE DISCARD",12);
    centered("MAKE 4 SETS AND ONE PAIR",15);
    centered("OR 7 PAIRS / 13 ORPHANS",17);
    centered("CLOSED TSUMO ALWAYS WINS",19);
    centered("RON NEEDS REACH OR YAKU",21);
    centered("START : RETURN TO THE GAME",25);
}
static void message(const char *s){u16 i=0;while(s[i] && i<38){note[i]=s[i];i++;}note[i]=0;}

int main(bool hard) {
    u16 pad,pressed;
    u32 seed;
    bool help=FALSE,dirty=TRUE;
    (void)hard;
    /* SGDK ROM boot/startup, exception vectors, VDP initialization, Z80,
       JOY driver and interrupt handling are supplied by SGDK itself. */
    VDP_setScreenWidth320();
    if(IS_PAL_SYSTEM){VDP_setScreenHeight240();screenRows=30;}
    else {VDP_setScreenHeight224();screenRows=28;}
    VDP_setBackgroundColor(0);
    VDP_setTextPlane(BG_A);
    VDP_setTextPalette(PAL0);
    PAL_setPalette(PAL0,uiPal,CPU);
    PAL_setPalette(PAL1,stonePal,CPU);
    VDP_loadTileData(mahjongTileArt,TILE_USER_INDEX,ART_TILE_COUNT,CPU);
    JOY_init();
    g.phase=MAJ_TITLE;
    note[0]=0;
    while(TRUE){
        pad=JOY_readJoypad(JOY_1);
        pressed=pad & (u16)~lastPad;
        lastPad=pad;
        if(g.phase==MAJ_TITLE){
            if(pressed&BUTTON_START){
                seed=0xA51231B9UL ^ (frameCounter*747796405UL);
                MAJ_start(&g,seed);dirty=TRUE;message("");
            }
        }else if(help){
            if(pressed&BUTTON_START){help=FALSE;dirty=TRUE;}
        }else if(g.phase==MAJ_PLAY){
            if(pressed&BUTTON_START){help=TRUE;dirty=TRUE;}
            else if(pressed&BUTTON_LEFT){
                if(!g.hRiichi)g.cursor=(g.cursor==0)?13:g.cursor-1;
                dirty=TRUE;
            }else if(pressed&BUTTON_RIGHT){
                if(!g.hRiichi)g.cursor=(g.cursor+1)%14;
                dirty=TRUE;
            }else if(pressed&BUTTON_A){
                if(!MAJ_humanTsumo(&g))message("NOT A COMPLETE WINNING HAND");
                else message("");
                dirty=TRUE;
            }else if(pressed&BUTTON_B){
                if(g.hRiichi){message("REACH ALREADY DECLARED");}
                else {g.riichiRequest=!g.riichiRequest;
                      message(g.riichiRequest?"CHOOSE TENPAI DISCARD / C":"REACH CANCELLED");}
                dirty=TRUE;
            }else if(pressed&BUTTON_C){
                if(!MAJ_humanDiscard(&g,g.hRiichi?13:g.cursor))
                    message(g.riichiRequest?"THAT DISCARD IS NOT TENPAI":"CANNOT DISCARD");
                else message("");
                dirty=TRUE;
            }
        }else if(g.phase==MAJ_RON){
            if(pressed&BUTTON_A){MAJ_humanRon(&g);message("");dirty=TRUE;}
            else if((pressed&BUTTON_B)||(pressed&BUTTON_C)){
                MAJ_passRon(&g);message("");dirty=TRUE;
            }
        }else{
            if(pressed&BUTTON_START){
                MAJ_newRound(&g);message("");dirty=TRUE;
            }
        }
        if(dirty){
            if(g.phase==MAJ_TITLE)titleScreen();
            else if(help)showHelp();
            else sceneGame();
            dirty=FALSE;
        }
        SYS_doVBlankProcess();
        frameCounter++;
    }
    return 0;
}
